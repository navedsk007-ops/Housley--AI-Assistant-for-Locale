export default async (req, context) => {
  if (req.method !== "POST") {
    return new Response("Method not allowed", { status: 405 });
  }

  const resendKey = Netlify.env.get("RESEND_API_KEY");
  if (!resendKey) {
    return new Response(JSON.stringify({ error: "Server not configured: missing RESEND_API_KEY" }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }

  const notifyTo = Netlify.env.get("NOTIFY_EMAIL");
  if (!notifyTo) {
    return new Response(JSON.stringify({ error: "Server not configured: missing NOTIFY_EMAIL" }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }

  let body;
  try {
    body = await req.json();
  } catch {
    return new Response(JSON.stringify({ error: "Invalid JSON body" }), {
      status: 400,
      headers: { "Content-Type": "application/json" },
    });
  }

  const { type, name, email, phone, unitType, slot, firstMessage } = body;

  let subject, html;
  if (type === "chat_started") {
    subject = `Someone just started chatting with Housley \u2014 Locale`;
    html = `
      <h2>New chat engagement on Housley (Locale demo)</h2>
      <p>A visitor sent their first message just now \u2014 no lead info captured yet.</p>
      <p><strong>First message:</strong> ${firstMessage || "\u2014"}</p>
    `;
  } else if (type === "booking") {
    subject = `Tour booked: ${name || "Unknown"} \u2014 Locale`;
    html = `
      <h2>New tour booked on Housley (Locale demo)</h2>
      <p><strong>Name:</strong> ${name || "\u2014"}</p>
      <p><strong>Email:</strong> ${email || "\u2014"}</p>
      <p><strong>Phone:</strong> ${phone || "\u2014"}</p>
      <p><strong>Unit type:</strong> ${unitType || "\u2014"}</p>
      <p><strong>Tour time:</strong> ${slot || "\u2014"}</p>
    `;
  } else {
    subject = `New lead: ${name || "Unknown"} \u2014 Locale`;
    html = `
      <h2>New lead captured on Housley (Locale demo)</h2>
      <p><strong>Name:</strong> ${name || "\u2014"}</p>
      <p><strong>Email:</strong> ${email || "\u2014"}</p>
      <p><strong>Phone:</strong> ${phone || "\u2014"}</p>
      <p><strong>Unit type:</strong> ${unitType || "\u2014"}</p>
    `;
  }

  try {
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${resendKey}`,
      },
      body: JSON.stringify({
        from: "Housley <onboarding@resend.dev>",
        to: notifyTo,
        subject,
        html,
      }),
    });

    const data = await res.json();
    if (!res.ok) {
      return new Response(JSON.stringify({ error: data?.message || "Email send failed" }), {
        status: res.status,
        headers: { "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ ok: true }), {
      status: 200,
      headers: { "Content-Type": "application/json" },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: "Failed to send email" }), {
      status: 502,
      headers: { "Content-Type": "application/json" },
    });
  }
};

export const config = {
  path: "/api/notify",
};
